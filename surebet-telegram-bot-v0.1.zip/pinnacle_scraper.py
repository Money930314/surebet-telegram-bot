# 實際版本會從 Pinnacle 抓賠率，目前為佔位
def get_pinnacle_odds():
    return []
